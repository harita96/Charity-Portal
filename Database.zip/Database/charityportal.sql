-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 01, 2018 at 07:35 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `charityportal`
--
CREATE DATABASE IF NOT EXISTS `charityportal` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `charityportal`;

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE IF NOT EXISTS `donor` (
  `User` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `OTP` varchar(25) NOT NULL,
  PRIMARY KEY (`User`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`User`, `Email`, `OTP`) VALUES
('DO001_Test', 'synocharpor@gmail.com', 'gZHWsg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `Name` varchar(50) NOT NULL,
  `Category` varchar(25) NOT NULL,
  `User` varchar(12) NOT NULL,
  `Password` varchar(12) NOT NULL,
  PRIMARY KEY (`User`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Name`, `Category`, `User`, `Password`) VALUES
('Test', 'DONOR', 'DO001_Test', '001_Test'),
('Hari', 'DONOR', 'DOHar', 'Har'),
('Test', 'NGO', 'NG001_Test', 'Meet'),
('Harita', 'NGO', 'NGHarita', 'Harlo'),
('Neel', 'NGO', 'NGNeel', 'Neel'),
('Test', 'USER', 'US001_Test', '001_Test'),
('Harita', 'USER', 'USHarita', 'Harita'),
('Meet', 'USER', 'USMe', 'Me');

-- --------------------------------------------------------

--
-- Table structure for table `ngo`
--

CREATE TABLE IF NOT EXISTS `ngo` (
  `User` varchar(25) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `OTP` varchar(25) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `Contact` bigint(13) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Trusty` varchar(50) NOT NULL,
  PRIMARY KEY (`User`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo`
--

INSERT INTO `ngo` (`User`, `Email`, `OTP`, `Address`, `Contact`, `Description`, `Trusty`) VALUES
('Meet', 'jdfjdfjldbfj', 'jjbj', '', 0, 'jkbjkbjk', 'jbjkbjkbj'),
('Meet12', 'Meet.mahjaan@gmail.com', '54879', '32 Rameshwar Park Society, Rajendra Cross Road, N.H.No 8, Odhav, Ahmedabad- 382415', 9725843001, '1. hugehfhiheoheo.\r\n2. hihfiwh\r\n3. hhifhiwh', 'Mr.Meet Mahajan'),
('NG001_Test', 'synocharpor@gmail.com', 'thZuJI', '', 0, '', ''),
('NG17Uj', 'meet.mahajan@gmail.com', 'buu', '', 7898456512, 'bug', 'Mr.Meet Mahajan'),
('NG1Meet', 'meet.mahajan@gmail.com', '78ejf', '', 7898456512, 'bhfyfy', 'Mr.Meet Mahajan'),
('NGH1arita', 'nknk', 'hi', '', 9785465212, 'vkdnivs', 'b'),
('NGHarita', 'synocharpor@gmail.com', 'zUlwc1', '', 0, '', ''),
('NGMe', 'Meet.mahjaan@gmail.com', 'bhukim', '', 7898654512, 'bjbggygujjbhk\r\n\r\n', 'Mr.Meet Mahajan'),
('NGMeeet', 'monoarchos@gmail.com', 'bj', '', 7898654512, 'bjbbj', 'Mr.Meet Mahajan'),
('NGMeet', 'meet.mahajan@gmail.com', 'jbdu', '', 7898456512, 'jfbsjfdjfbjd', 'Mr.Meet Mahajan'),
('NGsh', 'Meet.mahjaan@gmail.com', 'bu', '', 7898654512, 'nhi', 'Mr.Meet Mahajan');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `User` varchar(12) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `OTP` varchar(12) NOT NULL,
  PRIMARY KEY (`User`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User`, `Email`, `OTP`) VALUES
('US001_Test', 'synocharpor@gmail.com', 'cg4DyU');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
